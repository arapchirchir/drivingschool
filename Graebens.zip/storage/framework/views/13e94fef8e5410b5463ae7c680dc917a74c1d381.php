<?php $__env->startSection('title'); ?>
    School Information
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                School Information
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-6">
                                Fees Structure
                                <form action="<?php echo e(route('fees.structure')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <input type="file" name="fees_structure" class="form-control-sm form-control-file">
                                        <p class="text-danger"><?php $__errorArgs = ['fees_structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <button class="btn btn-info btn-sm" type="submit">Upload</button>
                                </form>
                            </div>
                            <div class="col-md-6">
                                <?php if(isset($fees_structure)): ?>
                                    <form action="<?php echo e(route('fees.structure.download', ['fees_structure' => $fees_structure->fees_structure])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-primary" type="submit">Fees Structure</button>
                                    </form>
                                <?php else: ?>
                                    Fees Structure unavailable
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Dennis\xampp\htdocs\Graebens\resources\views/graebens/school.blade.php ENDPATH**/ ?>