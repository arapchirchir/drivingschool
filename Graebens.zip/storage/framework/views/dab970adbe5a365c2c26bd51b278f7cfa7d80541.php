<?php $__env->startSection('title'); ?>
    Admin Homepage
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('title'); ?>
                <div class="float-right">
                    <button class="btn btn-primary btn-sm" type="button" data-toggle="modal"
                        data-target="#new-registration">Register</button>
                </div>
            </div>

            <div class="card-body">
                <table class="table table-responsive-sm">
                    <caption>Student List</caption>
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Registration Date</th>
                            <th scope="col">Contact</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <tr>
                                <th scope="row"><?php echo e($i); ?></th>
                                <td><?php echo e($student->first_name . ' ' . $student->last_name); ?></td>
                                <td><?php echo e($student->created_at->format('d-m-y')); ?></td>
                                <td><?php echo e($student->phone_number); ?></td>
                                <td>
                                    <form action="" method="POST">

                                        <a href="<?php echo e(route('student.edit', ['student_id' => $student->student_id])); ?>" title="show">
                                            <i class="fa fa-eye text-success  fa-lg"></i>
                                        </a>

                                        <a href="" title="edit">
                                            <i class="fa fa-edit  fa-lg"></i>
                                        </a>

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" title="delete"
                                            style="border: none; background-color:transparent;">
                                            <i class="fa fa-trash fa-lg text-danger"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php echo $students->links(); ?>

            </div>
        </div>
        <div id="new-registration" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">New Student Registration</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="px-2 py-2">
                        <form method="post" action="<?php echo e(route('OnlineRegistration')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="col-md-4 mb-3">
                                    <input type="text" name="first_name" class="form-control form-control-sm"
                                        id="validationServer01" placeholder="First Name" value="<?php echo e(old('first_name')); ?>">

                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <input type="text" name="last_name" class="form-control form-control-sm"
                                        id="validationServer02" placeholder="Last Name" value="<?php echo e(old('last_name')); ?>">

                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <input type="text" name="phone_number" class="form-control form-control-sm"
                                        id="validationServer02" placeholder="Phone Number"
                                        value="<?php echo e(old('phone_number')); ?>">

                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-4 mb-3">
                                    <select class="form-control form-control-sm" name="gender"
                                        value="<?php echo e(old('gender')); ?>">
                                        <option selected disabled>Gender</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <input type="text" name="user_identification" class="form-control form-control-sm"
                                        id="validationServer04" placeholder="National/Passport No"
                                        value="<?php echo e(old('user_identification')); ?>">
                                    <?php $__errorArgs = ['user_identification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <input type="email" name="user_email" class="form-control form-control-sm"
                                        id="validationServer05" placeholder="E-mail (Optional)"
                                        value="<?php echo e(old('user_email')); ?>">
                                    <?php $__errorArgs = ['user_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-4 mb-3">
                                    <select class="form-control form-control-sm" name="course_selection"
                                        value="<?php echo e(old('course_selection')); ?>">
                                        <option selected disabled>Select Course</option>
                                        <?php if(isset($courses) && count($courses) > 0): ?>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <option class="text-capitalize">No Courses</option>
                                        <?php endif; ?>

                                    </select>
                                    <?php $__errorArgs = ['course_selection'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <select class="form-control form-control-sm" name="course_branch" value="<?php echo e(old('course_branch')); ?>">
                                        <option  class="text-capitalize" disabled selected>Choose Branch</option>
                                        <?php if(isset($locations) && count($locations) > 0): ?>
                                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($location->id); ?>" class="text-capitalize"><?php echo e($location->branch_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <option class="text-capitalize">No Branches</option>
                                        <?php endif; ?>

                                    </select>
                                    <?php $__errorArgs = ['course_branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <button class="btn btn-primary btn-sm mb-4" id="button1" type="submit">Admit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Dennis\xampp\htdocs\Graebens\resources\views/home.blade.php ENDPATH**/ ?>