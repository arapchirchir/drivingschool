<?php $__env->startSection('title'); ?>
    Student Update
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                Student details update
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $registration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('student.update', ['student_id' => $student_details->student_id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="first_name">First Name</label>
                            <input type="text" name="first_name" class="form-control form-control-sm" value="<?php echo e($student_details->first_name); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="last_name">Last Name</label>
                            <input type="text" name="last_name" class="form-control form-control-sm" value="<?php echo e($student_details->last_name); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="phone_number">Phone Number</label>
                            <input type="text" name="phone_number" class="form-control form-control-sm" value="<?php echo e($student_details->phone_number); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="user_identification">Identification/Passport No.</label>
                            <input type="text" name="user_identification" class="form-control form-control-sm" value="<?php echo e($student_details->user_identification); ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="user_email">Email</label>
                            <input type="text" name="user_email" class="form-control form-control-sm" value="<?php echo e($student_details->user_email); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="course_selection">Course Selection</label>
                            <select name="course_selection" id="course_selection" class="form-control form-control-sm">
                                <option value="<?php echo e($student_details->course_selection); ?>"><?php echo e($student_details->id); ?></option>
                                <?php $__currentLoopData = $couses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="course_branch">Branch</label>
                            <select name="course_branch" id="course_branch" class="form-control form-control-sm">
                                <option value="<?php echo e($student_details->course_branch); ?>" selected><?php echo e($student_details->branch_name); ?></option>
                                <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->branch_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <button class="btn btn-success btn-sm" type="submit">Update</button>
                        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-sm btn-primary">Return</a>
                    </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Dennis\xampp\htdocs\Graebens\resources\views/graebens/editstudent.blade.php ENDPATH**/ ?>