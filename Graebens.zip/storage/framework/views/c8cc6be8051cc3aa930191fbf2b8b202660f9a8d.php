<?php $__env->startSection('title'); ?>
    Courses
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <nav aria-label="Branches" class="bg-light">
        <ol class="breadcrumb p-4">
            <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('Default')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('Courses')); ?>">Our Courses</a></li>
        </ol>
    </nav>
    <div class="container">
        <div class="row d-flex">
            <div class="col-2">
                <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo" class="img-fluid">
            </div>
            <div class="col-10">
                <ul>
                    <li class="h5" style="font-family: Times">
                        We are accredited by the National Transport and Service Board(NTSA) and our professional instructors
                        are ready to walk this journey with you.
                    </li>
                    <li class="h5" style="font-family: Times">
                        Our fees are standardized and we give enough practical time for our learners
                    </li>
                    <li class="h5" style="font-family: Times">
                        In order to receive a driving licence, you need to have an Identity card and have completed a 1 month
                        training from us. <br> <span class="font-italic text-uppercase font-weight-bold">nb: Issuance of Driving Licence is done by NTSA Kenya</span>
                    </li>
                </ul>
                <div class="h5 text-capitalize">below is a description of the driving license classes we offer</div>
            </div>
        </div>

        <hr class="solid">

        
        <div id="class-description">
            <div class="row d-flex">
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h5 font-weight-bold">License Category</div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="h5 font-weight-bold">Description of Vehicle to Operate and Restrictions</div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h5 font-weight-bold">Requirements</div>
                </div>
            </div>
            

            <div class="row d-flex">
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">Category A2</div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="h6">
                        <ul>
                            <li>Enables one to ride a motorcycle above 50cc</li>
                            <li>Can carry a maximum load of 60 Kg (for up to 400cc)</li>
                            <li>Can carry a passenger</li>
                        </ul>
                    </div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">18 Years of age and above and hold a National/Passport Identification</div>
                </div>
            </div>
            

            <div class="row d-flex table-hover">
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">Category B <span class="font-weight-bold">Light</span></div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="h6">
                        Light Vehicles (Saloon Cars )
                    </div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">18 Years of age and above and hold a National/Passport Identification</div>
                </div>
            </div>
            

            <div class="row d-flex">
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">Category B3 <span class="font-weight-bold">Professional</span></div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="h6">
                        <ul>
                            <li>Minimum age of 21 years</li>
                            <li>Equipped with a manual or automatic gear box</li>
                            <li>Can carry up to a maximum of 7 passengers</li>
                            <li>
                                Enables one to drive a light vehicle (passenger car) with a maximum Gross Vehicle Weight
                                (GVW) of 3500 kg with one light trailer (not exceeding 750 kg)
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">18 Years of age and above and hold a National/Passport Identification</div>
                </div>
            </div>
            

            <div class="row d-flex">
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">Category C1<span class="font-weight-bold"></span></div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="h6 text-capitalize">
                        Light trucks
                    </div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">18 Years of age and above and hold a National/Passport Identification</div>
                </div>
            </div>
            

            <div class="row d-flex">
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">Category D1<span class="font-weight-bold"></span></div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="h6 text-capitalize">
                        Van
                        <ul class="mt-2">
                            <li>Enables one to drive a van with a maximum of 14 passengers.</li>
                            <li>Equipped with manual or automatic gearbox</li>
                        </ul>
                    </div>
                </div>
                <div class="col-xm-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="h6">18 Years of age and above and hold a National/Passport Identification</div>
                </div>
            </div>
        </div>

        <hr class="solid">
        <div id="other-courses">
            <div class="text-center text-capitalize h3 text-primary"><span></span> Other courses <span></span></div>
            <div class="h5">Refresher Course</div>
        </div>

        <hr class="solid">
        
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.graebens', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Dennis\xampp\htdocs\Graebens\resources\views/pages/courses.blade.php ENDPATH**/ ?>