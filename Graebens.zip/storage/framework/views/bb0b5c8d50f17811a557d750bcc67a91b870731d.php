<?php $__env->startSection('title'); ?>
    Branches
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php endif; ?>
                    <?php $__errorArgs = ['branch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="float-right"><button class="btn btn-primary btn-sm" type="button"
                            data-target="#branch-registration-modal" data-toggle="modal">Register Branch</button></div>
                </div>
                <div class="card-body">
                    <table class="table table-responsive">
                        <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Branch Name</th>
                                <th>Contact Information</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($branches): ?>
                                <?php $i = 0; ?>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $i++; ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($branch->branch_name); ?></td>
                                        <td><?php echo e($branch->branch_contact); ?></td>
                                        <td>
                                            <form action="" method="POST">

                                                <a href="<?php echo e(route('Branches.show', ['id' => $branch->id])); ?>" title="show">
                                                    <i class="fa fa-eye text-success  fa-lg"></i>
                                                </a>

                                                <a href="<?php echo e(route('Branches.show', ['id' => $branch->id])); ?>" title="edit">
                                                    <i class="fa fa-edit  fa-lg"></i>
                                                </a>

                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit" title="delete"
                                                    style="border: none; background-color:transparent;">
                                                    <i class="fa fa-trash fa-lg text-danger"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <h3>No data</h3>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="branch-registration-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Branch Registration</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="post" action="<?php echo e(route('StoreBranch')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="branch_name">Branch Name</label>
                                        <input id="branch_name" class="form-control form-control-sm" type="text" name="branch_name">
                                        <?php $__errorArgs = ['branch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="branch_contact">Branch Contact</label>
                                        <input id="branch_contact" class="form-control form-control-sm" type="text" name="branch_contact">
                                        <?php $__errorArgs = ['branch_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer"><button class="btn btn-warning btn-sm" type="submit">Save</button></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Dennis\xampp\htdocs\Graebens\resources\views/graebens/branches.blade.php ENDPATH**/ ?>