<?php $__env->startSection('title'); ?>
    Online Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <nav aria-label="Branches" class="bg-light">
        <ol class="breadcrumb p-4">
            <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('Default')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('OnlineRegistration')); ?>">Online Registration</a></li>
        </ol>
    </nav>

    <?php echo $__env->make('common.registration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.graebens', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Dennis\xampp\htdocs\Graebens\resources\views/pages/online-registration.blade.php ENDPATH**/ ?>