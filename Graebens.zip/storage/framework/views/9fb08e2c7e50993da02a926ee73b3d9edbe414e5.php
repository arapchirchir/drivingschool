<?php $__env->startSection('title'); ?>
    Contacts
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <nav aria-label="Branches" class="bg-light">
        <ol class="breadcrumb p-4">
            <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('Default')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('Contact')); ?>">Our Contacts</a></li>
        </ol>
    </nav>
    <div class="container">
        <div class="row d-flex">
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-9 col-xl-9">
                <form method="post" action="<?php echo e(route('feedback')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-md-4 mb-3">
                            <input type="text" name="first_name" value="" class="form-control form-control-md" placeholder="First Name" value="<?php echo e(old('first_name')); ?>">
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4 mb-3">
                            <input type="text" name="last_name" value="" class="form-control form-control-md"
                                placeholder="Second Name" value="<?php echo e(old('last_name')); ?>">
                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4 mb-3">
                            <input type="email" name="email" value="" class="form-control form-control-md"
                                placeholder="E-mail" value="<?php echo e(old('email')); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="message">What is your thought?</label>
                        <textarea name="message" id="message" cols="30" rows="10" class="form-control"></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-secondary btn-sm" type="submit">Submit</button>
                    </div>
                </form>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3 col-xl-3">
                <div id="campus-1">
                    <div class="h6 font-weight-bold">
                        Jamii Villas, Ayany Kibera Drive (H/Office)
                    </div>
                    <div id="opening-hours">
                        <h6>Monday - Friday: <br> 07:00am - 18:00pm</h6>
                        <h6>Saturday: <br> 08:00am - 16:00pm</h6>
                        <h6>Sunday: Closed </h6>
                    </div>
                    <div id="contacts">
                        <div class="h6 font-weight-bold">
                            For inquiries
                        </div>
                        <h6>0722 819933</h6>
                    </div>
                    <hr>
                </div>
                <div id="campus-2">
                    <div class="h6 font-weight-bold">
                        Arcade Discounts Ngong Road (Adams Arcade)
                    </div>
                    <div id="opening-hours">
                        <h6>Monday - Friday: <br> 07:00am - 18:00pm</h6>
                        <h6>Saturday: <br> 08:00am - 16:00pm</h6>
                        <h6>Sunday: Closed </h6>
                    </div>
                    <div id="contacts">
                        <div class="h6 font-weight-bold">
                            For inquiries
                        </div>
                        <h6>0722 819933</h6>
                    </div>
                    <hr>
                </div>
                <div id="campus-2">
                    <div class="h6 font-weight-bold">
                        Kawangware 56
                    </div>
                    <div id="opening-hours">
                        <h6>Monday - Friday: <br> 07:00am - 18:00pm</h6>
                        <h6>Saturday: <br> 08:00am - 16:00pm</h6>
                        <h6>Sunday: Closed </h6>
                    </div>
                    <div id="contacts">
                        <div class="h6 font-weight-bold">
                            For inquiries
                        </div>
                        <h6>0722 819933</h6>
                    </div>
                    <hr>
                </div>
            </div>
        </div>
        
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.graebens', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Dennis\xampp\htdocs\Graebens\resources\views/pages/contacts.blade.php ENDPATH**/ ?>